
        t.checkDuplicates(&r, arr[i]);